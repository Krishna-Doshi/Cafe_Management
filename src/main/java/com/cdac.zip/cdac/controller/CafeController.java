package com.cdac.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import com.cdac.entity.Category;
import com.cdac.entity.Product;
import com.cdac.service.CategoryService;

@RestController
@RequestMapping("/cafe")
public class CafeController {

    @Autowired
    private CategoryService categoryService;

    // Cafe: Get all Categories
    @GetMapping("/categories")
    public List<Category> getAllCategories() {
        return categoryService.getAllCategories();
    }

    // Cafe: Get Category by ID
    @GetMapping("/categories/{categoryId}")
    public Category getCategoryById(@PathVariable int categoryId) {
        return categoryService.getCategoryById(categoryId);
    }

    // Cafe: Add Product to Category
    @PostMapping("/categories/{categoryId}/products")  //cafe/categories/{categodyId}/products
    public void addProductToCategory(@PathVariable int categoryId, @RequestBody Product product) {
        categoryService.addProductToCategory(categoryId, product);
    }
}
