package com.cdac.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cdac.dto.RegistrationStatus;
import com.cdac.entity.Admin;
import com.cdac.entity.Category;
import com.cdac.exception.AdminServiceException;
import com.cdac.repository.CategoryServiceRepository;
import com.cdac.service.AdminService;
import com.cdac.service.CategoryService;

@RestController
@CrossOrigin
public class AdminController {
	
	@Autowired
	private AdminService adminService;
	
	@PostMapping("/admin")
	public RegistrationStatus register(@RequestBody Admin admin){
		try {
			int id= adminService.register(admin);
			
			RegistrationStatus status = new RegistrationStatus();
			status.setStatus(true);
			status.setMessage("Admin registered successfully!!");
			status.setId(id);
			return status;
			
		}catch(AdminServiceException e) {
			RegistrationStatus status = new RegistrationStatus();
			status.setStatus(false);
			status.setMessage(e.getMessage());
			return status;
			
		}
		
	}
	 @Autowired
	    private CategoryServiceRepository categoryServiceRepository;

	    // Admin: Add Category
	    @PostMapping("/categories")
	    public void addCategory(@RequestBody Category category) {
	        categoryServiceRepository.addCategory(category);
	    }

}


