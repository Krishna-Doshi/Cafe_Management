package com.cdac.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cdac.entity.Cafe;

public interface CafeRepository extends JpaRepository<Cafe, Integer>{

}
