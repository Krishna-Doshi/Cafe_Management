package com.cdac.repository;

import com.cdac.entity.Order;
import com.cdac.entity.OrderItem;
import com.cdac.dto.ProductDetailsDto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface Order1Repository extends JpaRepository<Order, Long> {

    @Query("SELECT new com.cdac.dto.ProductDetailsDto(p.name, c.name, o.totalAmount, oi.quantity, ca.name) " +
            "FROM Order o " +
            "JOIN o.orderItems oi " +
            "JOIN oi.product p " +
            "JOIN p.category c " +
            "JOIN o.cafe ca "           )
    List<ProductDetailsDto> getProductDetailsForApprovedOrders();
}
