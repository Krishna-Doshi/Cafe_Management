package com.cdac.domain;

public enum RoleName {
    Admin,
    Cafe,
    Customer
}
