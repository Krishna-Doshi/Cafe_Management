package com.cdac.service;

import com.cdac.dto.ProductDetailsDto;
import com.cdac.repository.Order1Repository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cdac.entity.Order;
import java.util.List;

@Service
public class ProductService {

    @Autowired
    private Order1Repository order1Repository;

    public List<ProductDetailsDto> getProductDetailsForApprovedOrders() {
    	return order1Repository.getProductDetailsForApprovedOrders();
    }
}
