package com.cdac.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cdac.entity.Customer;
import com.cdac.exception.CustomerServiceException;
import com.cdac.repository.CustomerRepository;

@Service
public class CustomerService {
	
	@Autowired
	private CustomerRepository customerRepository;
	
	public int register(Customer customer) {
		Optional<Customer> checkCustomer = customerRepository.findByEmail(customer.getEmail());
		if(checkCustomer.isEmpty()) {
			Customer savedCustomer=customerRepository.save(customer);
			return savedCustomer.getId();
		}
		else throw new CustomerServiceException("Customer Already Registered");
			
		
		
		
	}
	public void login() {
		
	}

}
